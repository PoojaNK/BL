﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.BusinessDomain;
using OrderProcessing.BusinessLogic.Interfaces;
using OrderProcessing.Domain;

namespace BusinessLogic.UnitTests
{
    /// <summary>
    /// Summary description for OrderLogic
    /// </summary>
    [TestClass]
    public class OrderLogic
    {
        private IApi _api = new API();
        private Transaction testTransaction = null;
        public OrderLogic()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        // Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {
            testTransaction = new Transaction()
            {
                Date = DateTime.Now.Date,
                IsSuccess = true,
                OrderId = 1,
                Payment = new Payment() {Amount = 30, Date = DateTime.Now, Id = 3, OrderId = 1},
                Id = 1,
                Order = new Order() {Id = 1, ProductId = 1,}
            };
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void whenValidTransaction_EXpectSaveSuccess()
        {
            _api.OrderLogic.ProcessOrder(testTransaction);
        }
    }
}
