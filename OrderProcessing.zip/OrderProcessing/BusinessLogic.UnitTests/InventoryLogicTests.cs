﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.BusinessDomain;
using OrderProcessing.Domain;


namespace BusinessLogic.UnitTests
{
    [TestClass]
    public class InventoryLogicTests
    {
        API _api = new API();
        [TestMethod]
        public void WhenQueryInventory_ExpectProductCount()
        {
           
           var test = _api.InventoryLogic.GetProductAvailability(1);
            Assert.IsNull(test);
        }

        [TestMethod]
        public void WhenValidTransaction_ExpectSaveSuccess()
        {
            Transaction mockTransaction = new Transaction()
            {
                Date = DateTime.Now,
                IsSuccess = true,
                UserId = 1,
                Order = new Order()
                {
                    Id = 2,
                    IsConfirmed = true,
                    UserId = 1,
                    ProductId = 1,
                    Quantity = 2,
                    OrderDate = DateTime.Now,
                },
                Payment = new Payment()
                {
                    Id = 1,
                    OrderId = 2,
                    Amount = 20,
                    Last4Digits = 3456,
                    Date = DateTime.Now
                    
                }
            };
         
            _api.InventoryLogic.ExecuteTransaction( mockTransaction);

        }

        [TestMethod]
        public void WhenValidProductId_ExpectSaveSuccess()
        {
            var availableProductCnt = _api.DataContext.Inventories.FirstOrDefault(x => x.Id == 1)?.AvailableQuantity;
            availableProductCnt--;
            _api.InventoryLogic.UpdateProductAvailability(1);
            var newAvailableProductCnt = _api.DataContext.Inventories.FirstOrDefault(x => x.Id == 1)?.AvailableQuantity;
            Assert.AreEqual(availableProductCnt,newAvailableProductCnt);
            
        }

       
    }
}
