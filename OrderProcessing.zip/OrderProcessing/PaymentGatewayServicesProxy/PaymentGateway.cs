﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using log4net;
using OrderProcessing.Domain;
using PaymentGatewayServicesProxy.PaymentGatewayService;


namespace PaymentGatewayServicesProxy
{
    public class PaymentGateway
    {
        public ILog Log { get; protected set; }
        public PaymentResponse ChargePayment(Payment payment)
        {
            try
            {
                // Call WCF service method for calling payment gateway. 
                ISampleService wcfService = new SampleServiceClient();
                var serviceResponse = wcfService.ProcessPayment(paymentDetails: new PaymentDetails() { Amount = (decimal)payment.Amount, EncryptedCardId = payment.Last4Digits.ToString(CultureInfo.InvariantCulture) });
                if (serviceResponse.IsSuccess)
                {
                    return new PaymentResponse() { IsSuccess = true, TransactionStatus = "Completed" };
                }
                return new PaymentResponse() { IsSuccess = false, TransactionStatus = "Error" };
            }
            catch (Exception e)
            {
                Log.Error($"Exception in PaymentGatewayServicesProxy.ProcessPayment{e} ");
                return new PaymentResponse() { IsSuccess = false, TransactionStatus = String.Concat( "Exception Occured:" , e )};
            }
       
        }
    }
}
