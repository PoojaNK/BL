﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using log4net;
using OrderProcessing.BusinessDomain;
using OrderProcessing.BusinessLogic.Interfaces;

namespace OrderProcessing.BusinessLogic
{
    public class EmailLogic : IEmailLogic
    {
        private API _api;
        public ILog Log { get; protected set; }

        public EmailLogic(API aPI)
        {
            this._api = aPI;
            Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }

        public void SendEmailFormatted(
            string fromEmailAddress,
            List<string> toEmailAddresses,
            List<string> ccEmailAddresses,
            List<string> bccEmailAddresses,
            string subject,
            params string[] nameValuePairs)
        {
            System.Text.StringBuilder body = new StringBuilder();

            body.Append("<table style=\"width: 100%; font-size: 12px; font-family: Arial, Helvetica, sans-serif;\">");

            for (int i = 0; i < nameValuePairs.Length; i += 2)
            {
                body.Append("<tr>");
                body.AppendFormat("<td align=\"right\" valign=\"top\">{0}:</td>", nameValuePairs[i]);
                body.AppendFormat("<td align=\"left\" valign=\"top\">{0}</td>", nameValuePairs[i + 1]);
                body.Append("</tr>");
            }

            body.Append("</table>");

            this.SendEmail(
                fromEmailAddress,
                toEmailAddresses,
                ccEmailAddresses,
                bccEmailAddresses,
                subject,
                body.ToString());
        }


        public void SendEmail(
            string fromEmailAddress,
            List<String> toEmailAddresses,
            List<String> ccEmailAddresses,
            List<String> bccEmailAddresses,
            string subject,
            string body)
        {
            try
            {
                using (MailMessage message = new MailMessage())
                {
                    using (SmtpClient emailClient = new SmtpClient())
                    {

                        message.From = new MailAddress(fromEmailAddress);

                        if (toEmailAddresses != null)
                        {
                            // let's add addresses to the mail message
                            foreach (string email in toEmailAddresses)
                                message.To.Add(email);
                        }

                        if (ccEmailAddresses != null)
                        {
                            foreach (string email in ccEmailAddresses)
                                message.CC.Add(email);
                        }

                        if (bccEmailAddresses != null)
                        {
                            foreach (string email in bccEmailAddresses)
                                message.Bcc.Add(email);
                        }
                        
                        message.Subject = subject;
                        message.Body = string.Format( subject, body);
                        message.IsBodyHtml = true;
                        emailClient.Send(message);
                    }
                }
            }
            catch (Exception ex)
            {
               // Log exception
            }
        }
        
        /// <summary>
        /// Checks for Valid User Email Address
        /// </summary>
        /// <param name="emailString"></param>
        /// <returns></returns>
        public bool IsValidEmail(string emailString)
        {
            // Return true if strIn is in valid e-mail format.
            return Regex.IsMatch(emailString, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        }

    }
}
