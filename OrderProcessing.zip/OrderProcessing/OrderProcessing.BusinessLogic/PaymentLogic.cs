﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using OrderProcessing.BusinessDomain;
using OrderProcessing.Domain;
using PaymentGatewayServicesProxy;
using PaymentGatewayServicesProxy.PaymentGatewayService;

namespace OrderProcessing.BusinessLogic
{
    public class PaymentLogic :IPaymentLogic
    {
        private API _api;
        public ILog Log { get; protected set; }
        public PaymentLogic(API api)
        {
            this._api = api;
            Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }

        public bool ProcessPayment(Payment payment)
        {
            try
            {
                PaymentGatewayServicesProxy.PaymentGateway _paymentGateway = new PaymentGateway();
               var response =  _paymentGateway.ProcessPayment(payment);
               if (response.IsSuccess && response.TransactionStatus.Contains("Completed"))
               {
                   return true;
               }

            }
            catch (Exception e)
            {
               Log.Error(e);
            }

            return false;
        }
    }
}
