﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using OrderProcessing.BusinessDomain;
using OrderProcessing.BusinessLogic.Interfaces;
using OrderProcessing.Domain;

namespace OrderProcessing.BusinessLogic
{
    public class InventoryLogic :IInventoryLogic
    {
        private readonly IApi _api;
        public ILog Log { get; protected set; }
        public InventoryLogic(IApi api)
        {
            _api = api;
            Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public int? GetProductAvailability(int productId)
        {
            return _api.DataContext.Inventories.Where(x => x.Id == productId && x.AvailableQuantity>0).Select(y=>y.AvailableQuantity).FirstOrDefault();
          
        }
        public void UpdateProductAvailability(int productId)
        {
            var product= _api.DataContext.Inventories.FirstOrDefault(x => x.Id == productId && x.AvailableQuantity > 0);
            if (product != null) product.AvailableQuantity = product.AvailableQuantity--;
            _api.DataContext.SaveChangesAsync();
        }
        public bool ExecuteTransaction(Transaction transaction)
        {
            try
            {
                _api.DataContext.Transactions.Add(transaction);
                _api.DataContext.SaveChanges();
                return true;
            }
            catch (Exception e)
            {

                return false;
            }
        }

    }
}
