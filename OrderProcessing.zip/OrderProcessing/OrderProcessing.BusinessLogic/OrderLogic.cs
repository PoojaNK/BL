﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using OrderProcessing.BusinessDomain;
using OrderProcessing.BusinessLogic.Interfaces;
using OrderProcessing.Domain;



namespace OrderProcessing.BusinessLogic
{
    public class OrderLogic : IOrderLogic
    {
        private readonly IApi _api;
        public ILog Log { get; protected set; }
        public OrderLogic()
        {
        }

        public OrderLogic(IApi api)
        {
            _api = api;
            Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }
        /// <summary>
        /// Process Order method
        /// </summary>
        /// <param name="transaction"></param>
        public void ProcessOrder(Transaction transaction)
           {
             // Step 1 : check in inventory 
             // step 2 : call payment gateway proxy 
             transaction.Order = new Order()
             {
                 OrderDate = DateTime.UtcNow.Date, IsConfirmed =  true,
                 Product = new Product() {Id = 1, Name = "shopping bag", Desc = "shopping bag for me", Price = 85},
                 Quantity = 2, UserId = 2
             };
             // Step 1 : Check Inventory 
             if (_api.InventoryLogic.GetProductAvailability(1).HasValue)
             {
                // Verify Credit card gateway. 
                _api.PaymentLogic.ProcessPayment(transaction.Payment);
             }

             _api.InventoryLogic.UpdateProductAvailability(transaction.Order.ProductId);
             // SenD Email -- Last step 
           }
    }

}
