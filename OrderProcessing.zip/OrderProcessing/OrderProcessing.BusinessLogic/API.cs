﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderProcessing.BusinessLogic;
using OrderProcessing.BusinessLogic.Interfaces;
using OrderProcessing.Data;

namespace OrderProcessing.BusinessDomain
{
   public  class API : IDisposable , IApi
   {
        private BLDBEntity _dbContext = null;
        public API() : this(new BLDBEntity())
        {
        }

        public BLDBEntity DataContext
        {
            get => _dbContext;
            set => this._dbContext = value;
        }
        private API(BLDBEntity bldbEntity)
        {
            _dbContext = bldbEntity;
        }

        private void ReleaseUnmanagedResources()
        {
            // TODO release unmanaged resources here
        }

        protected virtual void Dispose(bool disposing)
        {
            ReleaseUnmanagedResources();
            if (disposing)
            {
            }
        }

        public int SaveChanges()
        {
            return this.DataContext.SaveChanges();
        }

        public Task<int> SaveChangesAsync()
        {
            return this.DataContext.SaveChangesAsync();
        }

        private InventoryLogic _inventoryLogic = null;
        public InventoryLogic InventoryLogic
        {
            get
            {
                if (_inventoryLogic == null)
                {
                    _inventoryLogic = new InventoryLogic(this);
                }

                return _inventoryLogic;
            }
        }
        IInventoryLogic IApi.InventoryLogic
        {
            get { return this.InventoryLogic; }
        }
        // Email Logic
        private EmailLogic _emailLogic = null;
        public EmailLogic EmailLogic
        {
            get
            {
                if (_emailLogic == null)
                {
                    _emailLogic = new EmailLogic(this);
                }

                return _emailLogic;
            }
        }
        IEmailLogic IApi.EmailLogic => this.EmailLogic;

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        // Payment Logic 
        private PaymentLogic _paymentLogic = null;
        public PaymentLogic PaymentLogic
        {
            get
            {
                if (_paymentLogic == null)
                {
                    _paymentLogic = new PaymentLogic(this);
                }

                return _paymentLogic;
            }
        }
        IPaymentLogic IApi.PaymentLogic => this._paymentLogic;
        // Order Logic
        private OrderLogic _orderLogic = null;
        public OrderLogic OrderLogic
        {
            get
            {
                if (_orderLogic == null)
                {
                    _orderLogic = new OrderLogic();
                }

                return _orderLogic;
            }
        }
        IOrderLogic IApi.OrderLogic => this._orderLogic;
        ~API()
        {
            Dispose(false);
        }
    }
}
