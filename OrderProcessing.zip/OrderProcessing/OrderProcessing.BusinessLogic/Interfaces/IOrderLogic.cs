﻿namespace OrderProcessing.BusinessLogic
{
    public interface IOrderLogic
    {
    }
}