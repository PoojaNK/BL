﻿using System.Collections.Generic;

namespace OrderProcessing.BusinessLogic.Interfaces
{
    public interface IEmailLogic
    {
        void SendEmailFormatted(
            string fromEmailAddress,
            List<string> toEmailAddresses,
            List<string> ccEmailAddresses,
            List<string> bccEmailAddresses,
            string subject,
            params string[] nameValuePairs);
    }
}