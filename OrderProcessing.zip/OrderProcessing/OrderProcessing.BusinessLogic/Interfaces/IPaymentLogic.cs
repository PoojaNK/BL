﻿using OrderProcessing.Domain;

namespace OrderProcessing.BusinessLogic
{
    public interface IPaymentLogic
    {
        bool ProcessPayment(Payment payment);
    }
}