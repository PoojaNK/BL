﻿using OrderProcessing.Domain;

namespace OrderProcessing.BusinessLogic.Interfaces
{
    public interface IInventoryLogic
    {
        int? GetProductAvailability(int productId);
        bool ExecuteTransaction(Transaction transaction);
        void UpdateProductAvailability(int productId);
    }
}
