﻿using System;
using OrderProcessing.Data;

namespace OrderProcessing.BusinessLogic.Interfaces
{
    public interface IApi :IDisposable
    {
        IInventoryLogic InventoryLogic { get; }
        BLDBEntity DataContext { get; }
        IEmailLogic EmailLogic { get; }
        IOrderLogic OrderLogic { get; }
        IPaymentLogic PaymentLogic { get; }
    }
}
