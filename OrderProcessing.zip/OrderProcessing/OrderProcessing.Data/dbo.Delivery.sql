﻿CREATE TABLE [dbo].[Delivery] (
    [Id]          INT NOT NULL,
    [OrderId]     INT NOT NULL,
    [ShippingId]  INT NOT NULL,
    [IsDelivered] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_Delivery_Order] FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Order] ([Id]),
	CONSTRAINT [FK_Delivery_Shipping] FOREIGN KEY ([ShippingId]) REFERENCES [dbo].[Shipping] ([Id])
   
   
);

