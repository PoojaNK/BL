﻿CREATE TABLE [dbo].[Product] (
    [Id]    INT        NOT NULL,
    [Name]  NCHAR (10) NULL,
    [Desc]  NCHAR (10) NULL,
    [Price] DECIMAL NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

