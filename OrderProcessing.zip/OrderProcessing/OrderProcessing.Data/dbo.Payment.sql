﻿CREATE TABLE [dbo].[Payment] (
    [Id]          INT         NOT NULL,
    [OrderId]     INT         NOT NULL,
    [Amount]      FLOAT (53)  NOT NULL,
    [Date]        DATETIME    NOT NULL,
    [Last4Digits] NUMERIC (4) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_Payment_Order] FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Order] ([Id])
   
);

