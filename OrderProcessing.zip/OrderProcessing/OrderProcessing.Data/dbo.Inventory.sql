﻿CREATE TABLE [dbo].[Inventory] (
    [Id]                INT NOT NULL,
    [ProductId]         INT NOT NULL,
    [TotalQuantity]     INT NOT NULL,
    [AvailableQuantity] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC) ,
	CONSTRAINT [FK_Inventory_Product] FOREIGN KEY ([ProductId]) REFERENCES [dbo].[Product] ([Id])
   
);

