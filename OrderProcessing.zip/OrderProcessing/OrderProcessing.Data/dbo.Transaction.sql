﻿CREATE TABLE [dbo].[Transaction] (
    [Id]        INT      NOT NULL,
    [UserId]    INT      NOT NULL,
    [OrderId]   INT      NOT NULL,
    [PaymentId] INT      NOT NULL,
    [Date]      DATETIME NOT NULL,
    [IsSuccess] BIT      NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_Transaction_Order] FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Order] ([Id]),
	CONSTRAINT [FK_Transaction_User] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User] ([Id]),
	CONSTRAINT [FK_Transaction_Payment] FOREIGN KEY ([PaymentId]) REFERENCES [dbo].[Payment] ([Id])
   
   
   
);

