﻿CREATE TABLE [dbo].[Shipping] (
    [Id]           INT      NOT NULL,
    [OrderId]      INT      NOT NULL,
    [ShippingDate] DATETIME NOT NULL,
    [IsShipped]    BIT      NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
	CONSTRAINT [FK_Shipping_Order] FOREIGN KEY ([OrderId]) REFERENCES [dbo].[Order] ([Id])
   
);

