﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using PaymentGatewayServices.DataContracts;

namespace PaymentGatewayServices
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class SampleService : ISampleService
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }

        public PaymentResponse ProcessPayment(PaymentDetails paymentDetails)
        {
            try
            {
                if (ChargePayment(paymentDetails.EncryptedCardId, paymentDetails.Amount))
                {
                    return new PaymentResponse() {IsSuccess = true, TransactionStatus = "Demo success"};
                }
                return new PaymentResponse() { IsSuccess = false, TransactionStatus = "Error in Payment gateway service - Lets ask Proxy class to log in Elmah / Log4net" };

            }
            catch (Exception e)
            {
               return new PaymentResponse() { IsSuccess = false, TransactionStatus = "Error in Payment gateway service - Lets ask Proxy class to log in Elmah / Log4net Exception:" + e.ToString() };

            }
        }

        private Boolean ChargePayment(string creditCardNumber, decimal amount)
        {
            // call THIRD Party service here. Before that Add Service ref and access their API. 
            return true; // Assuming our transaction is always true from the service provider
        }
    }
}
