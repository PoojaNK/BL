﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGatewayServices.DataContracts
{
    [DataContract]
    public class PaymentResponse
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool IsSuccess
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string TransactionStatus
        {
            get { return stringValue; }
            set { stringValue = value; }
        }

    }
}
