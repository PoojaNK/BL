﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace PaymentGatewayServices.DataContracts
{
    [DataContract]
    public class PaymentDetails
    {
        private string _encryptedCardId;
        string _customertName;
        private decimal _amount;
        [DataMember]
        public string CustomerName
        {
            get => _customertName;
            set => _customertName = value;
        }

        [DataMember]
        public string EncryptedCardId
        {
            get => _encryptedCardId;
            set => _encryptedCardId = value;
        }
        [DataMember]
        public decimal Amount
        {
            get => _amount;
            set => _amount = value;
        }

    }

}
