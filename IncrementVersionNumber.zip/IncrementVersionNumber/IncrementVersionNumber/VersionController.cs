﻿using System.Linq;

namespace BerkeleyLights
{
    using System;

    /// <summary>
    /// Defines the <see cref="VersionController" />
    /// </summary>
    public partial class VersionController
    {
        /// <summary>
        /// Gets or sets the VersionInputString
        /// </summary>
        public static string VersionInputString { get; set; }

        /// <summary>
        /// Gets or sets the IncrementAtIndexInputString
        /// </summary>
        public static string IncrementAtIndexInputString { get; set; }

        /// <summary>
        /// Gets or sets the IncrementAtIndex
        /// </summary>
        public static int? IncrementAtIndex { get; set; }

        /// <summary>
        /// Gets or sets the VersionInputArray
        /// </summary>
        public static string[] VersionInputArray { get; set; }

        /// <summary>
        /// The Main
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/></param>
        public static void Main(string[] args)
        {
            string[] input;
            Console.Write("Enter Version: ");
            var inputLine = Console.ReadLine();
            Console.Write("Enter Index for Versioning : ");
            var inputIndex = Console.ReadLine();
            input = new[] {inputLine, inputIndex};
            if (!ValidateUserInput(input))
            {
                Console.WriteLine($"--- Program exiting ---");
                ExitProgram();
                return;
            }

            IncrementVersion(VersionInputArray, Convert.ToInt32(inputIndex));
            ExitProgram();
        }

        /// <summary>
        /// The ExitProgram
        /// </summary>
        public static void ExitProgram()
        {
            Console.WriteLine("Press any key to stop...");
            Console.ReadKey();
        }
     
    }
}
