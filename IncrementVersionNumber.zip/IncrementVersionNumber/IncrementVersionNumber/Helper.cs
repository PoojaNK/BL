﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BerkeleyLights
{
    public partial class VersionController
    {
        /// <summary>
        /// The ValidateUserInput
        /// </summary>
        /// <param name="input">The input<see cref="string[]"/></param>
        /// <returns>The <see cref="bool"/></returns>
        public static bool ValidateUserInput(string[] input)
        {
            try
            {
                if (input == null)
                {
                    Console.WriteLine("User input is Empty");
                    return false;
                }
                if (input.Length > 2)
                {
                    Console.WriteLine("User Input has more than 2 parameters.Program expecting 2 input parameters.");
                    return false;
                }

                VersionInputString = input[0].ToLowerInvariant();
                IncrementAtIndexInputString = input[1];
                VersionInputArray = VersionInputString.Split('.');

                if (VersionInputArray.Length == 0) Console.WriteLine($"String.Split could not find delimiter char (.). Invalid Input.");
                var isSuccess = int.TryParse(IncrementAtIndexInputString, out var incrementIndex);
                IncrementAtIndex = incrementIndex;
                if (!isSuccess) // Eg Increment Index = 4 , 5 > 3 according to requirements
                {
                    Console.WriteLine($"Int32.TryParse could not parse '{IncrementAtIndexInputString}' to an int.");
                    return false;
                }
                // validations for input string 
                if (incrementIndex > VersionInputArray.Length)
                {
                    Console.WriteLine("Index is greater than version array.");
                    return false;
                }

            }
            catch (Exception e)
            {
                Console.WriteLine($"Unhandled exception in IncrementVersionNumber.ValidateUserInput() :{e} ");
                return false;
            }

            return true;
        }

    }
}
