﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BerkeleyLights
{
    /// <summary>
    /// The IncrementVersion
    /// </summary>
    /// <returns>The <see cref="string"/></returns>
    public partial class VersionController
    {
        private static string VersionIncrement()
        {
            try
            {
                char input = '\0';
                if (IncrementAtIndex != null )
                {
                    input = Convert.ToChar(VersionInputArray[(int) IncrementAtIndex]);
                }

                if (!char.IsLetterOrDigit(input))
                {
                    Console.WriteLine(
                        $"Char.IsLetterOrDigit says input is not a letter or digit. Cannot Increment version. ");
                    return String.Empty;
                }

                if (char.IsNumber(input))
                {
                    int.TryParse(input.ToString(), out var numResult);
                    return $" {++numResult}";
                }

                if (char.IsLetter(input))
                {
                    if (input == 'z')
                    {
                        Console.WriteLine($"Increment success (WITH ASSUMPTION) EDGE CASE : a.0.0.0 ");
                        return "a";
                    }

                    return ((char) (input + 1)).ToString().Trim();
                }

            }
            catch (Exception e)
            {
                return $"Unhandled exception in IncrementVersionNumber.IncrementVersion() :{e} ";

            }

            return String.Empty;
        }

        public static string IncrementVersion(string[] inputString, int incrementAtIndex)
        {
            try
            {
                if (IncrementAtIndex != null )
                {
                    var inputChar = Convert.ToChar(VersionInputArray[(int) IncrementAtIndex]);
                    string result;
                    switch (IncrementAtIndex)
                    {
                        case 0:
                            result = VersionIncrement();
                            Console.WriteLine($"Incremented Version : {result}.0.0.0");
                            break;
                        case 1:
                            result = VersionIncrement();
                            Console.WriteLine($"Incremented Version : {inputString[0]}.{result}.0.0");
                            break;
                        case 2:
                            result = VersionIncrement();
                            Console.WriteLine($"Incremented Version : {inputString[0]}.{inputString[1]}.{result}.0");
                            break;
                        case 3:
                            result = VersionIncrement();
                            Console.WriteLine($"Incremented Version : {inputString[0]}.{inputString[1]}.{inputString[2]}.{result}");
                            break;
                    }


                }
            }
            catch (Exception e)
            {
                return $"Unhandled exception in IncrementVersionNumber.IncrementVersion() :{e} ";

            }

            return String.Empty;
        }

    }
}
