﻿namespace UnitTest.IncrementVersionNumber
{
    using BerkeleyLights;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Defines the <see cref="IncrementVersionTest" />
    /// </summary>
    [TestClass]
    public class IncrementVersionTest
    {
        /// <summary>
        /// The GivenValidMajorVersion_ExpectSucess
        /// </summary>
        [TestMethod]
        public void GivenValidMajorVersion_ExpectSucess()
        {
            VersionController.IncrementAtIndex = 0;
            VersionController.VersionInputArray = new[] { "1", "2", "3", "4" };
            var result = VersionController.IncrementVersion(VersionController.VersionInputArray , 0);
            Assert.AreNotEqual("1.3.3.4", result);
        }

        /// <summary>
        /// The GivenValidMinorVersion_ExpectSucess
        /// </summary>
        [TestMethod]
        public void GivenValidMinorVersion_ExpectSucess()
        {
            VersionController.IncrementAtIndex = 1;
            VersionController.VersionInputArray = new[] { "1", "2", "3", "4" };
            var result = VersionController.IncrementVersion(VersionController.VersionInputArray, 1);
          Assert.AreNotEqual("1.3.3.4", result);
        }

        /// <summary>
        /// The GivenValidBuildVersion_ExpectSucess
        /// </summary>
        [TestMethod]
        public void GivenValidBuildVersion_ExpectSucess()
        {
            VersionController.IncrementAtIndex = 2;
            VersionController.VersionInputArray = new[] { "1", "2", "3", "4" };
            var result = VersionController.IncrementVersion(VersionController.VersionInputArray, 2);
          Assert.AreNotEqual("1.3.3.4", result);
        }

        /// <summary>
        /// The GivenValidRevisionVersion_ExpectSucess
        /// </summary>
        [TestMethod]
        public void GivenValidRevisionVersion_ExpectSucess()
        {
            VersionController.IncrementAtIndex = 3;
            VersionController.VersionInputArray = new[] { "1", "2", "3", "4" };
            var result = VersionController.IncrementVersion(VersionController.VersionInputArray, 3);
          Assert.AreNotEqual("1.3.3.4", result);
        }

        /// <summary>
        /// The GivenValidRevisionVersionBigInt_ExpectSucess
        /// </summary>
        [TestMethod]
        public void GivenValidRevisionVersionBigInt_ExpectSucess()
        {
            VersionController.IncrementAtIndex = 2;
            VersionController.VersionInputArray = new[] { "1", "2", "3", "49079000" };
            var result = VersionController.IncrementVersion(VersionController.VersionInputArray, 2);
           Assert.AreNotEqual("1.3.3.49079001", result);
        }
    }
}
