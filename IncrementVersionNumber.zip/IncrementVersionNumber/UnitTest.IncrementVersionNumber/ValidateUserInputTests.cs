﻿namespace UnitTest.IncrementVersionNumber
{
    using BerkeleyLights;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    /// <summary>
    /// Defines the <see cref="ValidateUserInputTests" />
    /// </summary>
    [TestClass]
    public class ValidateUserInputTests
    {
        /// <summary>
        /// The GivenValidInput_ExpectSuccess
        /// </summary>
        [TestMethod]
        public void GivenValidInput_ExpectSuccess()
        {
            string[] testInput = new[] { "1.2.3.4", "1" };
            var result = VersionController.ValidateUserInput(testInput);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// The GivenInvalidIndex_ExpectFailure
        /// </summary>
        [TestMethod]
        public void GivenInvalidIndex_ExpectFailure()
        {
            string[] testInput = new[] { "1.2.3.4", "9" };
            var result = VersionController.ValidateUserInput(testInput);
            Assert.IsFalse(result);
        }

        /// <summary>
        /// The GivenInvalidVersion_ExpectFailure
        /// </summary>
        [TestMethod]
        public void GivenInvalidVersion_ExpectFailure()
        {
            string[] testInput = new[] { "1.2.3", "1" };
            var result = VersionController.ValidateUserInput(testInput);
            Assert.IsFalse(result);
        }

        /// <summary>
        /// The GivenInvalidVersionFormat_ExpectFailure
        /// </summary>
        [TestMethod]
        public void GivenInvalidVersionFormat_ExpectFailure()
        {
            string[] testInput = new[] { "1,2,3,4", "1" };
            var result = VersionController.ValidateUserInput(testInput);
            Assert.IsTrue(result);
        }

        /// <summary>
        /// The GivenInvalidVersionData_ExpectFailure
        /// </summary>
        [TestMethod]
        [Ignore("Scenario not handled in coding")]
        public void GivenInvalidVersionData_ExpectFailure()
        {
            string[] testInput = new[] { "1.2.$.^", "1" };
            var result = VersionController.ValidateUserInput(testInput);
            Assert.IsFalse(result);
        }
    }
}
