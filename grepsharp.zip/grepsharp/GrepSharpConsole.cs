namespace grepsharp
{
    using CommandLine.Utility;
    using grepsharp.Helper;
    using System;
    using System.Collections;
    using System.IO;
    using System.Security;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    public class GrepSharpConsole
    {
        //Option Flags
        /// <summary>
        /// Defines the m_bRecursive
        /// </summary>
        private bool m_bRecursive;

        /// <summary>
        /// Defines the m_bIgnoreCase
        /// </summary>
        private bool m_bIgnoreCase;

        /// <summary>
        /// Defines the m_bJustFiles
        /// </summary>
        private bool m_bJustFiles;

        /// <summary>
        /// Defines the m_bFileNameLineNumbers
        /// </summary>
        private bool m_bFileNameLineNumbers;

        /// <summary>
        /// Defines the m_bCountLines
        /// </summary>
        private bool m_bCountLines;

        /// <summary>
        /// Defines the m_strRegEx
        /// </summary>
        private string m_strRegEx;

        /// <summary>
        /// Defines the m_strPattern
        /// </summary>
        private string m_strPattern;

        /// <summary>
        /// Defines the m_bInverseMatch
        /// </summary>
        private bool m_bInverseMatch;

        /// <summary>
        /// Defines the m_iLeadingTrailingContext
        /// </summary>
        private int m_iLeadingTrailingContext;

        /// <summary>
        /// Defines the m_strFiles
        /// </summary>
        private string m_strFiles;

        //ArrayList keeping the Files
        /// <summary>
        /// Defines the m_arrFiles
        /// </summary>
        private ArrayList m_arrFiles = new ArrayList();

        //Properties
        /// <summary>
        /// Gets or sets a value indicating whether Recursive
        /// </summary>
        public bool Recursive
        {
            get { return m_bRecursive; }
            set { m_bRecursive = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether IgnoreCase
        /// </summary>
        public bool IgnoreCase
        {
            get { return m_bIgnoreCase; }
            set { m_bIgnoreCase = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether JustFiles
        /// </summary>
        public bool JustFiles
        {
            get { return m_bJustFiles; }
            set { m_bJustFiles = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether FileNameAndLineNumbers
        /// </summary>
        public bool FileNameAndLineNumbers
        {
            get { return m_bFileNameLineNumbers; }
            set { m_bFileNameLineNumbers = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether CountLines
        /// </summary>
        public bool CountLines
        {
            get { return m_bCountLines; }
            set { m_bCountLines = value; }
        }

        /// <summary>
        /// Gets or sets the StringPattern
        /// </summary>
        public string StringPattern
        {
            get { return m_strPattern; }
            set { m_strPattern = value; }
        }

        /// <summary>
        /// Gets or sets the RegEx
        /// </summary>
        public string RegEx
        {
            get { return m_strRegEx; }
            set { m_strRegEx = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether InverseMatch
        /// </summary>
        public bool InverseMatch
        {
            get { return m_bInverseMatch; }
            set { m_bInverseMatch = value; }
        }

        /// <summary>
        /// Gets or sets the LeadingTrailingContext
        /// </summary>
        public int LeadingTrailingContext
        {
            get { return m_iLeadingTrailingContext; }
            set { m_iLeadingTrailingContext = value; }
        }

        /// <summary>
        /// Gets or sets the Files
        /// </summary>
        public string Files
        {
            get { return m_strFiles; }
            set { m_strFiles = value; }
        }

        //Build the list of Files
        /// <summary>
        /// The GetFiles
        /// </summary>
        /// <param name="strDir">The strDir<see cref="String"/></param>
        /// <param name="strExt">The strExt<see cref="String"/></param>
        /// <param name="bRecursive">The bRecursive<see cref="bool"/></param>
        private void GetFiles(String strDir, String strExt, bool bRecursive)
        {
            //search pattern can include the wild characters '*' and '?'
            string[] fileList = Directory.GetFiles(strDir, strExt);
            for (int i = 0; i < fileList.Length; i++)
            {
                if (File.Exists(fileList[i]))
                    m_arrFiles.Add(fileList[i]);
            }
            if (bRecursive == true)
            {
                //Get recursively from subdirectories
                string[] dirList = Directory.GetDirectories(strDir);
                for (int i = 0; i < dirList.Length; i++)
                {
                    GetFiles(dirList[i], strExt, true);
                }
            }
        }

        //Search Function
        /// <summary>
        /// The Search
        /// </summary>
        public void Search()
        {
            String strDir = Environment.CurrentDirectory;
            //First empty the list
            m_arrFiles.Clear();
            //Create recursively a list with all the files complying with the criteria
            String[] astrFiles = m_strFiles.Split(new Char[] { ',' });
            for (int i = 0; i < astrFiles.Length; i++)
            {
                //Eliminate white spaces
                astrFiles[i] = astrFiles[i].Trim();
                GetFiles(strDir, astrFiles[i], m_bRecursive);
            }
            //Now all the Files are in the ArrayList, open each one
            //iteratively and look for the search string
            String strResults = "Grep Results:\r\n\r\n";
            String strReadLine;
            int iMatchCount;
            bool bEmpty = true;
            IEnumerator enm = m_arrFiles.GetEnumerator();
            while (enm.MoveNext())
            {
                try
                {
                    string[] inputReadFileStringArray = File.ReadAllLines((string)enm.Current);

                    iMatchCount = 0;
                    bool bFirst = true;
                    for (int iLine = 0; iLine < inputReadFileStringArray.Length; iLine++)
                    {
                        strReadLine = inputReadFileStringArray[iLine];

                        bool isMatchFound;

                        if (!String.IsNullOrEmpty(m_strPattern))
                        {
                            if (m_bIgnoreCase == true)
                            {
                                StringComparison comp = StringComparison.OrdinalIgnoreCase;
                                isMatchFound = strReadLine.Contains(m_strPattern, comp);
                            }
                            else
                            {
                                StringComparison comp = StringComparison.Ordinal;
                                isMatchFound = strReadLine.Contains(m_strPattern, comp);
                            }
                        }
                        else //Using Regular Expressions as a real Grep
                        {
                            Match mtch;
                            if (m_bIgnoreCase == true)
                                mtch = Regex.Match(strReadLine, m_strRegEx, RegexOptions.IgnoreCase);
                            else
                                mtch = Regex.Match(strReadLine, m_strRegEx);

                            isMatchFound = mtch.Success == true ? true : false;
                        }

                        if (isMatchFound == true)
                        {
                            bEmpty = false;
                            iMatchCount++;
                            if (bFirst == true)
                            {
                                if (m_bJustFiles == true)
                                {
                                    strResults += (string)enm.Current + "\r\n";
                                    break;
                                }
                                else if (m_bFileNameLineNumbers == false)
                                    strResults += (string)enm.Current + ":\r\n";
                                bFirst = false;
                            }

                            //Add the Line to Results string, check for inverse match
                            if (m_bInverseMatch == false)
                            {
                                if (m_iLeadingTrailingContext > 0)
                                {
                                    //trailing
                                    for (int i = 1; i <= m_iLeadingTrailingContext && i <= iLine; i++)
                                    {
                                        string readLeadingLine = inputReadFileStringArray[iLine - i];
                                        strResults += "  " + readLeadingLine + "\r\n";
                                    }

                                    if (m_bFileNameLineNumbers == true)
                                        strResults += "  " + (string)enm.Current + ":" + strReadLine + ":" + iLine + "\r\n";
                                    else
                                        strResults += "  " + strReadLine + "\r\n";

                                    //leading
                                    for (int i = 1; i <= m_iLeadingTrailingContext && i <= inputReadFileStringArray.Length; i++)
                                    {
                                        string readTrailingLine = inputReadFileStringArray[iLine + i];
                                        strResults += "  " + readTrailingLine + "\r\n";
                                    }
                                }
                                else
                                {
                                    if (m_bFileNameLineNumbers == true)
                                        strResults += "  " + (string)enm.Current + ":" + strReadLine + ":" + iLine + "\r\n";
                                    else
                                        strResults += "  " + strReadLine + "\r\n";
                                }
                            }
                        }
                        else
                        {
                            if (m_bInverseMatch == true)
                            {
                                if (m_bFileNameLineNumbers == true)
                                    strResults += "  " + (string)enm.Current + ":" + strReadLine + ":" + iLine + "\r\n";
                                else
                                    strResults += "  " + strReadLine + "\r\n";
                            }
                        }
                    }
                    //sr.Close();
                    if (bFirst == false)
                    {
                        if (m_bCountLines == true)
                            strResults += "  " + iMatchCount + " Lines Matched\r\n";
                        strResults += "\r\n";
                    }
                }
                catch (SecurityException)
                {
                    strResults += "\r\n" + (string)enm.Current + ": Security Exception\r\n\r\n";
                }
                catch (FileNotFoundException)
                {
                    strResults += "\r\n" + (string)enm.Current + ": File Not Found Exception\r\n";
                }
            }
            if (bEmpty == true)
                Console.WriteLine("No matches found!");
            else
                Console.WriteLine(strResults);
        }

        //Print Help
        /// <summary>
        /// The PrintHelp
        /// </summary>
        private static void PrintHelp()
        {
            Console.WriteLine("Usage: grep [-h|-H]");
            Console.WriteLine("       grep [-c] [-d] [-l] [-i] [-s]  -C number -p pattern -r regex -f files");
            Console.WriteLine("� -c: Return count of matching lines per file.");
            Console.WriteLine("� -i: Prepend the output lines with filename.");
            Console.WriteLine("� -p<PATTERN> : String pattern to search");
            Console.WriteLine("� -r<REGEX> : Regex pattern to search(use C# regex)");
            Console.WriteLine("� -n: Inverse the match. (Show all lines that do not match the pattern)");
            Console.WriteLine("� -l<NUM> : Print NUM lines of output, wait for user input, then show next NUM lines.");
            Console.WriteLine("� -C<NUM> : Print NUM lines of leading and trailing context.");
        }

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/></param>
        [STAThread]
        public static void Main(string[] args)
        {
#if DEBUG
            args = new string[] { "grep", "-c", "-r", "DISCOVERY", "-f", "TextFile1.txt" };
#endif
            // Command line parsing

            Arguments CommandLine = new Arguments(args);
            if (CommandLine["h"] != null || CommandLine["H"] != null)
            {
                PrintHelp();
                return;
            }
            // The working object
            GrepSharpConsole grepsharp = new GrepSharpConsole();
            // The arguments -r or -p and -f are mandatory
            if (CommandLine["p"] != null)
                grepsharp.StringPattern = (string)CommandLine["p"];
            else
             if (CommandLine["r"] != null)
                grepsharp.RegEx = (string)CommandLine["r"];
            else
            {
                Console.WriteLine("Error: No String Pattern or Regular Expression specified!");
                Console.WriteLine();
                PrintHelp();
                return;
            }

            if (CommandLine["f"] != null)
            {
                grepsharp.Files = (string)CommandLine["f"];
            }
            else
            {
                Console.WriteLine("Error: No Search Files specified!");
                Console.WriteLine();
                PrintHelp();
                return;
            }

            if (CommandLine["C"] != null)
            {
                grepsharp.LeadingTrailingContext = Convert.ToInt32(CommandLine["C"]);
            }

            grepsharp.Recursive = (CommandLine["s"] != null);
            grepsharp.IgnoreCase = (CommandLine["d"] != null);
            grepsharp.InverseMatch = (CommandLine["n"] != null);
            grepsharp.JustFiles = (CommandLine["j"] != null);
            if (grepsharp.JustFiles == true)
                grepsharp.FileNameAndLineNumbers = false;
            else
                grepsharp.FileNameAndLineNumbers = (CommandLine["i"] != null);
            if (grepsharp.JustFiles == true)
                grepsharp.CountLines = false;
            else
                grepsharp.CountLines = (CommandLine["c"] != null);
            // Do the search
            grepsharp.Search();
        }
    }
}
