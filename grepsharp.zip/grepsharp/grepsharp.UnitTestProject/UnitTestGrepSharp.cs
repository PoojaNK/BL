﻿namespace grepsharp.UnitTestProject
{
    using CommandLine.Utility;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System;

    /// <summary>
    /// Defines the <see cref="UnitTestGrepSharp" />
    /// </summary>
    [TestClass]
    public class UnitTestGrepSharp
    {
        /// <summary>
        /// The TestMethod1
        /// </summary>
        [TestMethod]
        public void TestMethod1()
        {
            string[] args = new string[] { "-c", "-d", "-i", "-C", "2", "-p", "discovery", "-f", "TextFile1.txt" };
            // grepsharp.GrepSharpConsole.Main(args);

            Arguments CommandLine = new Arguments(args);
           
            GrepSharpConsole grepsharp = new GrepSharpConsole();
            // The arguments -r or -p and -f are mandatory
            if (CommandLine["p"] != null)
                grepsharp.StringPattern = (string)CommandLine["p"];
            else
             if (CommandLine["r"] != null)
                grepsharp.RegEx = (string)CommandLine["r"];
            else
            {
                Console.WriteLine("Error: No String Pattern or Regular Expression specified!");
                Console.WriteLine();
                return;
            }

            if (CommandLine["f"] != null)
            {
                grepsharp.Files = (string)CommandLine["f"];
            }
            else
            {
                Console.WriteLine("Error: No Search Files specified!");
                Console.WriteLine();
                return;
            }

            if (CommandLine["C"] != null)
            {
                grepsharp.LeadingTrailingContext = Convert.ToInt32(CommandLine["C"]);
            }

            grepsharp.Recursive = (CommandLine["s"] != null);
            grepsharp.IgnoreCase = (CommandLine["d"] != null);
            grepsharp.InverseMatch = (CommandLine["n"] != null);
            grepsharp.JustFiles = (CommandLine["j"] != null);
            if (grepsharp.JustFiles == true)
                grepsharp.FileNameAndLineNumbers = false;
            else
                grepsharp.FileNameAndLineNumbers = (CommandLine["i"] != null);
            if (grepsharp.JustFiles == true)
                grepsharp.CountLines = false;
            else
                grepsharp.CountLines = (CommandLine["c"] != null);
            // Do the search
            grepsharp.Search();
        }
    }
}
