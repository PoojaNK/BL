﻿namespace grepsharp.Helper
{
    using System;

    /// <summary>
    /// Defines the <see cref="StringExtensions" />
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// The Contains
        /// </summary>
        /// <param name="str">The str<see cref="String"/></param>
        /// <param name="substring">The substring<see cref="String"/></param>
        /// <param name="comp">The comp<see cref="StringComparison"/></param>
        /// <returns>The <see cref="bool"/></returns>
        public static bool Contains(this String str, String substring,
                                    StringComparison comp)
        {
            if (substring == null)
                throw new ArgumentNullException("substring",
                                                "substring cannot be null.");
            else if (!Enum.IsDefined(typeof(StringComparison), comp))
                throw new ArgumentException("comp is not a member of StringComparison",
                                            "comp");

            return str.IndexOf(substring, comp) >= 0;
        }
    }
}
